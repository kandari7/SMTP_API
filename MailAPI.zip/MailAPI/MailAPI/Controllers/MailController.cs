﻿using MailAPI.Models;
using MailAPI.Persistence.Interface;
using Microsoft.AspNetCore.Mvc;

namespace MailAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MailController : Controller
    {
        private IMailService _mailService;
        public MailController(IMailService mailService)
        {
            _mailService = mailService;
        }
        [HttpPost]
        public IActionResult SendMail([FromBody] MailRequest mailRequest)
        {
            try
            {
                if (mailRequest.to != null && mailRequest.to != "" && mailRequest.cc != null && mailRequest.cc != "" && mailRequest.subject != null && mailRequest.subject != "" && mailRequest.body != null && mailRequest.body != "")
                {
                    string result = _mailService.SendMail(mailRequest);
                    if (result == "Mail sent successfully")
                    {
                        return Ok(new { status = "200", message = result });
                    }
                    else
                    {
                        return BadRequest(new { status = "400", message = "Mail could not be sent" });
                    }
                }
                else
                {
                    return BadRequest(new { status = "400", message = "all fields required" });
                }
            }
            catch(Exception e)
            {
                return NotFound(new { status = "402", message = "Mail could not be sent" });
            }
        }
    }
}
