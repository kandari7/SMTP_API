﻿using MailAPI.Models;
using MailAPI.Persistence.Interface;
using Microsoft.Extensions.Configuration;
using System.Net.Mail;
namespace MailAPI.Persistence.Services
{
    public class MailService : IMailService
    {
        private readonly IConfiguration _Configuration;

        public MailService(IConfiguration Configuration)
        {
            _Configuration = Configuration;
        }
        public string SendMail(MailRequest mailRequest)
        {

            int Port = Convert.ToInt16(_Configuration.GetSection("Mail").GetSection("Port").Value);
            string Mailfrom = Convert.ToString(_Configuration.GetSection("Mail").GetSection("Mailfrom").Value);
            MailMessage mail = new MailMessage();
            string SMTP = Convert.ToString(_Configuration.GetSection("Mail").GetSection("SMTP").Value);
            //string ADUser = Convert.ToString(_Configuration.GetSection("Mail").GetSection("ADUserName").Value);
            //string Password = Convert.ToString(_Configuration.GetSection("Mail").GetSection("ADPassWord").Value);
            string bcc = Convert.ToString(_Configuration.GetSection("Mail").GetSection("BCC").Value);
            SmtpClient smtpClient = new SmtpClient(SMTP);
            try
            {
                //if (Convert.ToString(_Configuration.GetSection("Mail").GetSection("Environment").Value) == "Local")
                //{
                //    smtpClient.Credentials = new System.Net.NetworkCredential(ADUser, Password);
                //}
                if (!string.IsNullOrEmpty(mailRequest.to))
                {
                    List<string> result = mailRequest.to.Split(";").ToList();

                    foreach (var item in result)
                    {
                        mail.To.Add(item);
                    }
                }
                mail.From = new MailAddress(Mailfrom);
                if (!string.IsNullOrEmpty(mailRequest.cc))
                {
                    List<string> result = mailRequest.cc.Split(';').ToList();

                    foreach (var item in result)
                    {
                        mail.CC.Add(item);
                    }
                }
                mail.Bcc.Add(bcc);
                mail.Subject = mailRequest.subject;
                mail.IsBodyHtml = true;
                mail.Body = mailRequest.body;
                smtpClient.Port = Port;
                smtpClient.Send(mail);
                return "Mail sent successfully";
            }
            catch (Exception e)
            {
                return e.ToString();
            }
        }
    }
}
