﻿using MailAPI.Models;

namespace MailAPI.Persistence.Interface
{
    public interface IMailService
    {
        string SendMail(MailRequest mailRequest);
    }
}